import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, Router, CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class IntroGuard implements  CanActivate {
  constructor(public router: Router) {}
  async canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Promise<boolean> {
    let isComplete = true;
    if (localStorage.getItem('isFirstTime') == null) {
      this.router.navigateByUrl('/intro');
      isComplete = false;
     }
    return isComplete;
  }
}
