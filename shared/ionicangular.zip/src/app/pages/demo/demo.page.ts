import { Component, OnInit } from '@angular/core';

import { CameraService } from '../../shared/services/camera.service';
import { GeolocationService } from '../../shared/services/geolocation.service';
@Component({
  selector: 'app-demo',
  templateUrl: './demo.page.html',
  styleUrls: ['./demo.page.scss'],
})
export class DemoPage implements OnInit {

  constructor(private cs: CameraService, private gs: GeolocationService) { }

  ngOnInit() {
  }

  camera() {
    this.cs.selectPhoto().then((image) => {
      alert(image);
    });
  }
  getLocation() {
    this.gs.locationRequest().then((location) => {
      alert(JSON.stringify(location));
    }).catch((error) => {
      alert(JSON.stringify(error));
    });
  }
}
