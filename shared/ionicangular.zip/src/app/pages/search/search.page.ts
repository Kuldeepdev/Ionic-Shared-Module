import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from '../../shared/services/shared.service';
import { WordpressService } from '../../shared/services/wordpress.service';
import { Post } from '../../modals/post';
@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
})
export class SearchPage implements OnInit, AfterViewInit {
  @ViewChild('searchbar') searchbar: any;
  public search: string = '';
  public posts: Array<Post> = [];
  public categoryId: any = '';
  public page: number = 1;
  constructor(private arouter: ActivatedRoute, public ss: SharedService, private ws: WordpressService) {
  }

  ngOnInit() {
    this.arouter.params.subscribe((params) => {
      this.categoryId = params['id'] === undefined ? '' : params['id'];
      this.posts = [];
      this.page = 1;
      this.getData();
    });
  }

  ngAfterViewInit() {
    this.searchbar.setFocus();
  }

  getData() {
    this.ws.getPost(0, this.categoryId, this.search, this.page ).subscribe((data) => {
      data.forEach((element, key) => {
        let postKey = this.posts.push(
          new Post({
            id: element.id,
            title: element.title.rendered,
            descriptionShort: element.excerpt.rendered,
            description: element.content.rendered,
            date: element.modified,
            featured_media: element.featured_media
          })
        );
        postKey--;
        if (this.posts[postKey].featured_media !== 0) {
          this.ws
            .getImage(this.posts[postKey].featured_media)
            .subscribe(imageData => {
              this.posts[postKey].image = imageData.source_url;
            });
        }
      });
    });
  }
  loadData(event) {
    this.page++;
    this.getData();
    event.target.disabled = true;
  }

  ionChange() {
    this.page = 1;
    this.posts = [];
    this.getData();
  }

}
