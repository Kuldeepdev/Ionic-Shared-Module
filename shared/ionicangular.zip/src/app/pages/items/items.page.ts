import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IonInfiniteScroll } from '@ionic/angular';

import { SharedService } from '../../shared/services/shared.service';
import { WordpressService } from '../../shared/services/wordpress.service';

import { Post } from '../../modals/post';
@Component({
  selector: 'app-items',
  templateUrl: './items.page.html',
  styleUrls: ['./items.page.scss'],
})
export class ItemsPage implements OnInit {
  @ViewChild(IonInfiniteScroll) infiniteScroll: IonInfiniteScroll;
  public posts: Array<Post> = [];
  public skeletonRepeat: number = 3;
  apiParams = {
    orderby: 'id',
    order: 'asc',
    per_page: this.ss.environment.per_page,
    page: 1,
    categories: this.ss.environment.appCategoryId
  };
  constructor(private arouter: ActivatedRoute, public ss: SharedService, private ws: WordpressService) {
  }

  ngOnInit() {
    this.arouter.params.subscribe((params) => {
      this.posts = [];
      this.apiParams.categories = params['id'] === undefined ? this.ss.environment.appCategoryId : params['id'];
      this.apiParams.page = 1;
      this.getData();
    });
  }
  ionViewDidEnter() {
    this.infiniteScroll.disabled = false;
  }
  getData(event = null, isPulled = false) {
    if (isPulled) {
      this.posts = [];
      this.apiParams.page = 1;
      this.infiniteScroll.disabled = false;
    }
    const loader = this.apiParams.page === 1 ? 'true' : 'false';
    this.ss.hitApi("posts", 'GET' , this.apiParams, loader).subscribe((data: any) => {
      if (this.apiParams.page === 1 && data == '') {
        this.skeletonRepeat = 0;
      }
      data.forEach((element, key) => {
        let postKey = this.posts.push(
          new Post({
            id: element.id,
            title: element.title.rendered,
            descriptionShort: element.excerpt.rendered,
            description: element.content.rendered,
            date: element.modified,
            featured_media: element.featured_media,
            image: '/assets/shapes.svg'
          })
        );
        postKey--;
        if (this.posts[postKey].featured_media !== 0) {
          this.ws
            .getImage(this.posts[postKey].featured_media)
            .subscribe(imageData => {
              this.posts[postKey].image = imageData.source_url;
            });
        }
      });
      this.apiParams.page++;
      if (event !== null) { event.target.complete(); }
    },
    error => {
      if (error.error.data.status === 400) {
        event.target.complete();
        event.target.disabled = true;
      }
    });
  }

}
