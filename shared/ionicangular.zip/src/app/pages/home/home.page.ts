import { Component, OnInit } from "@angular/core";
import { SharedService } from "../../shared/services/shared.service";
import { WordpressService } from "../../shared/services/wordpress.service";

import { Category } from "../../modals/category";
@Component({
  selector: "app-home",
  templateUrl: "./home.page.html",
  styleUrls: ["./home.page.scss"]
})
export class HomePage implements OnInit {
  categories: Category[] = [];
  constructor(public ss: SharedService, private ws: WordpressService) {}

  ngOnInit() {
    this.getData();
  }
  getData() {
    const apiParams = {
      orderby: 'count',
      order: 'desc',
      parent: this.ss.environment.appCategoryId
    };
    this.ss.hitApi("categories", 'GET' , apiParams).subscribe((data: any) => {
        data.forEach((element, key) => {
          this.categories.push(
            new Category({
              id: element.id,
              name: element.name,
              image: element.description === "" ? "../../../../assets/icon/icon.png" : element.description,
              count: element.count
            })
          );
        });
    });
  }
}
