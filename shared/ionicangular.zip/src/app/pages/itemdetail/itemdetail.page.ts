import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SharedService } from '../../shared/services/shared.service';
import { WordpressService } from '../../shared/services/wordpress.service';

import { Post } from '../../modals/post';
@Component({
  selector: 'app-itemdetail',
  templateUrl: './itemdetail.page.html',
  styleUrls: ['./itemdetail.page.scss'],
})
export class ItemdetailPage implements OnInit {
  public post: Post;
  public postId: any;
  constructor(private arouter: ActivatedRoute, public ss: SharedService, private ws: WordpressService) {
  }

  ngOnInit() {
    this.arouter.params.subscribe((params) => {
      this.postId = params['id'];
      this.getData();
    });
  }
  getData() {
    this.ws.getPost(this.postId).subscribe((data: any) => {
      this.post = new Post({
        id: data.id,
        title: data.title.rendered,
        descriptionShort: data.excerpt.rendered,
        description: data.content.rendered,
        date: data.modified,
        featured_media: data.featured_media
      });
      if (this.post.featured_media !== 0) {
        this.ws.getImage(this.post.featured_media).subscribe(imageData => {
          this.post.image = imageData.source_url;
        });
      }
    });
  }

}
