import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from '../../shared/services/shared.service';
@Component({
  selector: 'app-intro',
  templateUrl: './intro.page.html',
  styleUrls: ['./intro.page.scss']
})
export class IntroPage implements OnInit {
  slides = [];
  constructor(private router: Router, private ss: SharedService) {
    this.slides = [
      {
        title: 'WELCOME',
        description:
          'Welcome all ' +
          ss.environment.name +
          ' lovers. Post your exprience, find ' +
          ss.environment.name +
          ' HD videos and training videos.',
        image: 'assets/icon/icon.png',
        color: '#ef3c2a'
      },
      {
        title: 'Post',
        description:
          'Post your exprience of ' +
          ss.environment.name +
          ', post multiple images and text.',
        image: 'assets/icon/icon.png',
        color: '#ffcc00'
      },
      {
        title: 'HD Video',
        description: 'Find Full HD video of ' + ss.environment.name + '.',
        image: 'assets/icon/icon.png',
        color: '#007aff'
      },
      {
        title: 'Training Video',
        description:
          'Find training video of ' +
          ss.environment.name +
          ', and improve your game.',
        image: 'assets/icon/icon.png',
        color: '#0ae912'
      },
      {
        title: 'Search Video',
        description: 'Search video of ' + ss.environment.name + '',
        image: 'assets/icon/icon.png',
        color: '#ff2d55'
      }
    ];
  }

  ngOnInit() {}

  goToHome() {
    localStorage.setItem('isFirstTime', '1');
    this.router.navigate(['home']);
  }
}
