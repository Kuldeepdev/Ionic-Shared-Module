import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { IntroGuard } from './guards/intro.guard';

const routes: Routes = [
  {
    path: '',
    loadChildren: './pages/home/home.module#HomePageModule',
    canActivate: [IntroGuard]
  },
  { path: 'intro', loadChildren: './pages/intro/intro.module#IntroPageModule' },
  { path: 'home', loadChildren: './pages/home/home.module#HomePageModule' },
  { path: 'search', loadChildren: './pages/search/search.module#SearchPageModule' },
  { path: 'search/:id', loadChildren: './pages/search/search.module#SearchPageModule' },
  { path: 'items', loadChildren: './pages/items/items.module#ItemsPageModule' },
  { path: 'items/:id', loadChildren: './pages/items/items.module#ItemsPageModule' },
  { path: 'itemdetail/:id', loadChildren: './pages/itemdetail/itemdetail.module#ItemdetailPageModule' },
  { path: 'demo', loadChildren: './pages/demo/demo.module#DemoPageModule' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
