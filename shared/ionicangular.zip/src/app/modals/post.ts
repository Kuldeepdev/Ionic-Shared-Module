export interface PostInterface {
    id?: number;
    title?: string;
    description?: string;
    descriptionShort?: string;
    date?: string;
    image?: string;
    featured_media?: number;
}

export class Post implements PostInterface{
    id?: number;
    title?: string;
    description?: string;
    descriptionShort?: string;
    date?: string;
     image?: string = '/assets/shapes.svg';
     featured_media?: number = 0;
    constructor(properties: PostInterface) {
        for (let property in properties) {
            this[property] = properties[property];
        }
    }
}
