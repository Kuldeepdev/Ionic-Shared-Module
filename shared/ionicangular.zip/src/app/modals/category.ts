export interface CategoryInterface {
    id?: string;
    name?: string;
    count?: number;
    image?: string;
}
export class Category implements CategoryInterface{
    id?: string;
    name?: string;
    count?: number;
    image?: string = '../../../../assets/icon/icon.png';
    constructor(properties: CategoryInterface) {
        for (let property in properties) {
            this[property] = properties[property];
        }
    }
}
