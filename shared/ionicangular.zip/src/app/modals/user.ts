interface UserInterface {
    isFirstTime?: Boolean
}
export class User implements UserInterface{
    isFirstTime?: Boolean = false;
    constructor(properties: UserInterface) {
        for (let property in properties) {
            this[property] = properties[property];
        }
    }
}
