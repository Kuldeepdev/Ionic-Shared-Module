// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  name: 'Ionics',
  appVersion: 1.0,
  packageId: 'com.ionic',
  APIBASEURL: 'http://192.168.0.71/wordpress/index.php/wp-json/wp/v2/',
  per_page: 2,
  appCategoryId: 10,
  playStoreURL: 'https://play.google.com/store/apps/details?id=in.comin.d11',
  ratePlayStoreURL: 'market://details?id=in.comin.d11',
  socialShare: {
    msg: 'Check out D11 app for your smartphone. Download it today from',
    subject: "D11",
    image: "https://lh3.googleusercontent.com/0c4j8l3Nd9tsU66R_bHCr6ouwLfa1ERqz4wAyPg1UGdk2P3B_ZiWf0QPPU6mhsCe6-M",
    url: "https://play.google.com/store/apps/details?id=in.comin.d11"
  },
  admob: {
    banner: 'ca-app-pub-6628857297388785/8876143359',
    interstitial: 'ca-app-pub-6628857297388785/2088686803'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
