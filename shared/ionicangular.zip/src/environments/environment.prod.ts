export const environment = {
  production: true,
  name: 'Ionic & Angular',
  appVersion: 1.0,
  packageId: 'in.comin.ionic',
  APIBASEURL: 'http://mynurserybazaar.com/comin/comin/index.php/wp-json/wp/v2/',
  per_page: 5,
  appCategoryId: 9,
  playStoreURL: 'https://play.google.com/store/apps/details?id=in.comin.ionic',
  ratePlayStoreURL: 'market://details?id=in.comin.ionic',
  socialShare: {
    msg: 'Check out Ionic app for your smartphone. Download it today from',
    subject: "Ionic",
    image: "https://lh3.googleusercontent.com/0c4j8l3Nd9tsU66R_bHCr6ouwLfa1ERqz4wAyPg1UGdk2P3B_ZiWf0QPPU6mhsCe6-M",
    url: "https://play.google.com/store/apps/details?id=in.comin.ionic"
  },
  admob: {
    banner: 'ca-app-pub-6628857297388785/8876143359',
    interstitial: 'ca-app-pub-6628857297388785/2088686803'
  }
};
