import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormBuilder, Validators } from '@angular/forms';
//import { GooglePlus } from '@ionic-native/google-plus';
// Providers
import { BasicProvider } from '../../providers/basic/basic';
import { UserProvider } from '../../providers/user/user';
import { FirebaseProvider } from '../../providers/firebase/firebase';
//import { FacebookProvider } from '../../providers/facebook/facebook';


@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  public loginForm;
  constructor(public navCtrl: NavController, public navParams: NavParams, public builder: FormBuilder, public bp: BasicProvider, public up: UserProvider, public fp: FirebaseProvider) {
    this.loginForm = builder.group({
      'email': ['', Validators.compose([Validators.required, Validators.pattern('([a-zA-Z0-9_.]{1}[a-zA-Z0-9_.]*)((@[a-zA-Z\-]{2}[a-zA-Z\-]*)[\\\.]([a-zA-Z]{2}|[a-zA-Z]{3}))([\\\.]([a-zA-Z]{2}|[a-zA-Z]{3}))?')])],
      'password': ['', Validators.required]
    })
  }

  public formSubmit() {
    var validation_message = {
      'email': {
        'required': 'Please enter email.',
        'pattern': 'Please enter valid email'
      },
      'password': {
        'required': 'Please enter password.'
      }
    };
    if (this.bp.validation(this.loginForm, validation_message)) {
      this.fp.login(this.loginForm.value.email, this.loginForm.value.password)
        .then(
          success => {
            this.up.login(success[0]);
            console.log(success)
           this.navCtrl.setRoot('HomePage');
          }, error => {  }
        )
    }
  }

// Facebook login
  public facebook() {
    // this.bp.showLoader();
    // this.fb.login().then(
    //   success => {
    //     this.fb.getUserData().then(
    //       success => {
    //         var submitData = { email: success.email, fname: success.first_name, lname: success.last_name, fb_id: success.id, fb_link: '', fb_image: '' };
    //         this.bp.hitApi('users/fbLogin', 'POST', submitData, false, true)
    //           .subscribe(
    //             userData => {
    //               this.bp.hideLoader();
    //               if (userData.status) {
    //                 this.up.login(userData.data);
    //                 if (userData.data.is_answered) {
    //                   this.navCtrl.setRoot(HomePage)
    //                 } else {
    //                   this.navCtrl.setRoot('QuestionPage')
    //                 }
    //               } else {
    //                 this.bp.showAlert(userData.message, 'OK', () => { });
    //               }
    //             }, error => { })
    //       }, error => {
    //         this.bp.hideLoader();
    //       }
    //     )
    //   }, error => {
    //     this.bp.hideLoader();
    //   }
    // )
  }
// Google login
  public googleplus() {
    // this.bp.showLoader();
    // this.googlePlus.login({})
    //   .then(success => {
    //     var submitData = { email: success.email, fname: success.displayName, lname: '', google_id: success.userId };
    //     this.bp.hitApi('users/googleLogin', 'POST', submitData, false, true)
    //       .subscribe(
    //         userData => {
    //           this.bp.hideLoader();
    //           if (userData.status) {
    //             this.up.login(userData.data);
    //             if (userData.data.is_answered) {
    //               this.navCtrl.setRoot(HomePage)
    //             } else {
    //               this.navCtrl.setRoot('QuestionPage')
    //             }
    //           } else {
    //             this.bp.showAlert(userData.message, 'OK', () => { });
    //           }
    //         }, error => { })
    //   }, error => {
    //     this.bp.hideLoader();
    //   })
    //   .catch(error => {
    //     this.bp.hideLoader();
    //   });
  }


  public signupPage() {
    this.navCtrl.push('SignupPage');
  }
  public forgotpasswordPage() {
    this.navCtrl.push('ForgotpasswordPage');
  }
  public goToHome(){
    this.navCtrl.setRoot('HomePage');
  }
}
