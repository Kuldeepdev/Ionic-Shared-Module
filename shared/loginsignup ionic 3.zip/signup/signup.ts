import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormBuilder, Validators } from '@angular/forms';
//import { GooglePlus } from '@ionic-native/google-plus';
// Providers
import { BasicProvider } from '../../providers/basic/basic';
import { UserProvider } from '../../providers/user/user';
import { FirebaseProvider } from '../../providers/firebase/firebase';
//import { FacebookProvider } from '../../providers/facebook/facebook';


@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {
  public signupForm;
  constructor(public navCtrl: NavController, public navParams: NavParams, public builder: FormBuilder, public bp: BasicProvider, public up: UserProvider, public fp: FirebaseProvider) {
    this.signupForm = builder.group({
      fname: ['', Validators.compose([Validators.required])],
      lname: ['', Validators.compose([Validators.required])],
      email: ['', Validators.compose([Validators.required, Validators.pattern('([a-zA-Z0-9_.]{1}[a-zA-Z0-9_.]*)((@[a-zA-Z\-]{2}[a-zA-Z\-]*)[\\\.]([a-zA-Z]{2}|[a-zA-Z]{3}))([\\\.]([a-zA-Z]{2}|[a-zA-Z]{3}))?')])],
      password: ['', Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(20)])]
    })
  }
  public formSubmit() {
    var validation_message = {
      'fname': {
        'required': 'Please enter first name.'
      },
      'lname': {
        'required': 'Please enter last name.'
      },
      'email': {
        'required': 'Please enter email.',
        'pattern': 'Please enter valid email'
      },
      'password': {
        'required': 'Please enter password.',
        'minlength': "Your password should be 8 to 20 characters long.",
        'maxlength': "Your password should be 8 to 20 characters long.",
      }
    };
    if (this.bp.validation(this.signupForm, validation_message)) {
      var submitData = this.signupForm.value;
      submitData.deviceId = this.bp.deviceId;
      this.fp.signup(submitData)
        .then(
          success => {
            console.log(success)
            //this.navCtrl.push('LoginPage');
             this.up.login(success[0]);
              this.navCtrl.setRoot('HomePage')
          }, error => { }
        )
    }
  }
// Facebook login
  public facebook() {
    // this.bp.showLoader();
    // this.fb.login().then(
    //   success => {
    //     this.fb.getUserData().then(
    //       success => {
    //         var submitData = { email: success.email, fname: success.first_name, lname: success.last_name, fb_id: success.id, fb_link: '', fb_image: '' };
    //         this.bp.hitApi('users/fbLogin', 'POST', submitData, false, true)
    //           .subscribe(
    //             userData => {
    //               this.bp.hideLoader();
    //               if (userData.status) {
    //                 this.up.login(userData.data);
    //                 if (userData.data.is_answered) {
    //                   this.navCtrl.setRoot(HomePage)
    //                 } else {
    //                   this.navCtrl.setRoot('QuestionPage')
    //                 }
    //               } else {
    //                 this.bp.showAlert(userData.message, 'OK', () => { });
    //               }
    //             }, error => { })
    //       }, error => {
    //         this.bp.hideLoader();
    //       }
    //     )
    //   }, error => {
    //     this.bp.hideLoader();
    //   }
    // )
  }
// Google login
  public googleplus() {
    // this.bp.showLoader();
    // this.googlePlus.login({})
    //   .then(success => {
    //     var submitData = { email: success.email, fname: success.displayName, lname: '', google_id: success.userId };
    //     this.bp.hitApi('users/googleLogin', 'POST', submitData, false, true)
    //       .subscribe(
    //         userData => {
    //           this.bp.hideLoader();
    //           if (userData.status) {
    //             this.up.login(userData.data);
    //             if (userData.data.is_answered) {
    //               this.navCtrl.setRoot(HomePage)
    //             } else {
    //               this.navCtrl.setRoot('QuestionPage')
    //             }
    //           } else {
    //             this.bp.showAlert(userData.message, 'OK', () => { });
    //           }
    //         }, error => { })
    //   }, error => {
    //     this.bp.hideLoader();
    //   })
    //   .catch(error => {
    //     this.bp.hideLoader();
    //   });
  }

  public loginPage() {
    this.navCtrl.pop();
  }
 public static(slug){
   this.navCtrl.push("StaticPage",{slug: slug});
 }
}
